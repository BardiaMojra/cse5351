/*
 * Copyright © 2015 Inria.  All rights reserved.
 * See COPYING in top-level directory.
 */

#ifndef HWLOC_PORT_WINDOWS_WINDOWSX_H
#define HWLOC_PORT_WINDOWS_WINDOWSX_H


#endif /* HWLOC_PORT_WINDOWS_WINDOWSX_H */
