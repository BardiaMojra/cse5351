/*
 * Copyright (C) by Argonne National Laboratory
 *     See COPYRIGHT in top-level directory
 */

#include "hydra.h"
#include "bsci.h"
#include "bscu.h"

HYD_status HYDT_bsci_finalize(void)
{
    HYD_status status = HYD_SUCCESS;

    HYDU_FUNC_ENTER();

    if (HYDT_bsci_fns.rmk_finalize) {
        status = HYDT_bsci_fns.rmk_finalize();
        HYDU_ERR_POP(status, "RMK returned error while finalizing\n");
    }

    if (HYDT_bsci_fns.launcher_finalize) {
        status = HYDT_bsci_fns.launcher_finalize();
        HYDU_ERR_POP(status, "RMK returned error while finalizing\n");
    }

    /* unset O_NONBLOCK on stdout, stderr */
    status = HYDU_sock_set_block(STDOUT_FILENO);
    HYDU_ERR_POP(status, "error while finalizing stdout\n");
    status = HYDU_sock_set_block(STDERR_FILENO);
    HYDU_ERR_POP(status, "error while finalizing stderr\n");

  fn_exit:
    HYDU_FUNC_EXIT();
    return status;

  fn_fail:
    goto fn_exit;
}
